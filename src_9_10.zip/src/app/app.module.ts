import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRouter } from './app.router';

import { CoreModule } from './core/core.module';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { MeuTimeComponent } from './meu-time/meu-time.component';
import { BuscarPartidasComponent } from './buscar-partidas/buscar-partidas.component';
import { MarcacaoComponent } from './marcacao/marcacao.component';
import { CadastroComponent } from './cadastro/cadastro.component';



@NgModule({
	declarations: [
		AppComponent,
		HomeComponent,
		MeuTimeComponent,
		BuscarPartidasComponent,
		MarcacaoComponent,
		CadastroComponent
	],
	imports: [
		AppRouter,
		BrowserModule,
		CoreModule
	],
	providers: [],
	bootstrap: [AppComponent]
})
export class AppModule { }
