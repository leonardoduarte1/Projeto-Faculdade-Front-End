import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buscar-partidas',
  templateUrl: './buscar-partidas.component.html',
  styleUrls: ['./buscar-partidas.component.css']
})
export class BuscarPartidasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
