import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-meu-time',
	templateUrl: './meu-time.component.html',
	styleUrls: ['./meu-time.component.css']
})
export class MeuTimeComponent implements OnInit {

	constructor() { }

	ngOnInit() {
	}

}
