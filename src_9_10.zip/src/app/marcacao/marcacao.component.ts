import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marcacao',
  templateUrl: './marcacao.component.html',
  styleUrls: ['./marcacao.component.css']
})
export class MarcacaoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
