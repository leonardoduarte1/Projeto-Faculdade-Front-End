export class LocalPartida {
	public Id: number;
	public Nome: string;
	public telefone: string;
	public IdCidade: number;
	public IdEstado: number;
	public Ativo: boolean = false;
}