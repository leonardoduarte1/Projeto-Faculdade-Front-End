export class Jogador {
	public Id: number;
	public Nome: string;
	public Email: string;
	public Telefone: string;
	public IdPosicao: number;
	public IdTime: number;
}