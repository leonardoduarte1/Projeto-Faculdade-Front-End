export class Partida {
	public Id: number;
	public DataPartida: string;
	public IdLocalPartida: number;
	public IdTimeA: number;
	public IdTimeB: number;
	public IdTimeVencedor: number;
	public IdSituacao: number;
	public PlacarTimeA: number;
	public PlacarTimeB: number;
}