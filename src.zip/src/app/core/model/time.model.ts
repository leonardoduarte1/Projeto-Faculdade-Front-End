export class Time {
	public Id: number;
	public Nome: string;
	public Proprietario: string;
	public Email: string;
	public Telefone: string;
	public IdBairro: number;
	public IdCidade: number;
	public IdEstado: number;
	public Emblema: string;
	public Senha: string;
	public DataCriacao: Date;
}